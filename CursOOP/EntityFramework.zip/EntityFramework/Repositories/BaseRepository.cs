using EntityFramework.Models;

namespace EntityFramework.Repositories;

public class BaseRepository<T> : IRepository<T> where T : Base
{
    private CursOOPDbContext db;

    public BaseRepository(CursOOPDbContext db)
    {
        this.db = db;
    }
    
    public void Create(T obj)
    {
        db.Set<T>().Add(obj);
        db.SaveChanges();
    }

    public void Update(T oldObj, T updObj)
    {
        var obj = Read().Find(b => b.Id.Equals(oldObj.Id));
        obj = updObj;
        obj.Id = oldObj.Id;
        db.SaveChanges();
    }

    public void Delete(T obj)
    {
        db.Set<T>().Remove(obj);
        db.SaveChanges();
    }

    public List<T> Read()
    {
        return db.Set<T>().ToList();
    }

}