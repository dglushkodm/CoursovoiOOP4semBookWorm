using EntityFramework.Models;
using EntityFramework.Repositories;
using EntityFramework.Services;

namespace EntityFramework;

public class UnitOfWork : IDisposable
{
    public IRepository<Book> Books { get; set; }
    public IRepository<User> Users { get; set; }
    
    public ICommentService Comments { get; set; }
    public UnitOfWork()
    {
        var db = new CursOOPDbContext();
        
        Books = new BaseRepository<Book>(db);
        Users = new BaseRepository<User>(db);
        Comments = new CommentService(db);
    }
    
    public void Dispose()
    {
        
    }
}