using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EntityFramework.Models
{
    public class Book : Base
    {
        private Guid _id;
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get { return _id; } set { _id = value; } }
        
        private string _name;
        public string Name
        {
            get { return _name;} 
            set { _name = value; }
        }
        
        private string _author;
        public string Author { get { return _author; } set { _author = value; } }
        
        private string _shortdesc;
        public string Shortdesc
        {
            get { return _shortdesc; }
            set { _shortdesc= value; }
        }
        
        private string _fulldesc;
        public string Fulldesc
        {
            get { return _fulldesc; }
            set { _fulldesc= value; }
        }
        
        private string _year;
        public string Year
        {
            get { return _year; }
            set { _year = value; }
        }
        private byte[] _img;
        public byte[] Img
        {
            get { return _img; }
            set { _img = value; }
        }
        private byte[] _imgBack;
        public byte[] ImgBack
        {
            get { return _imgBack; }
            set { _imgBack = value; }
        }
        public ICollection<User>? Users { get; set; }
    }
}