using System.ComponentModel;

namespace EntityFramework.Models;

public enum ROLES
{
    [Description("Client")]
    CLIENT,
    [Description("Admin")]
    ADMIN
}