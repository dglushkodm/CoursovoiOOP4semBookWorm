namespace EntityFramework.Models;

public class Base
{
    public Guid Id { get; set; }
}